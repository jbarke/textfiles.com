#include    <stdio.h>
#ifndef __TURBOC__
#include    <malloc.h>
#else
#include    <alloc.h>
#endif
#include    <stdlib.h>
#include    "opus_api.h"



void cdecl main()
{
    char    *msgpath;
    char    *filepath;
    char    *echopath;
    int     i;
    int     msg_attr;
    long    user_pos;
    long    m_pos;
    long    f_pos;
    long    e_pos;
    char    *s[] = { "WALRUS",
                     "MEADOW",
                     "NEWOPUS",
                     "LASIE",
                     "PRADOX",   /* This one is intentionall bad */
                     NULL};

    char    *users[] = { "Doug Boone",
                     "John Lamb",
                     "Pete Seeger",
                     "Wynn Wagner",
                     "Douglas Boone",
                     NULL};

    for (i = 0;i<5;i++) {
        e_pos = get_echopos(s[i],"c:\\system\\");
        if (echopath = get_echopath(s[i],"c:\\system\\")) {
            printf("\nEcho path for %s is %s %ld",s[i],echopath,e_pos);
            free(echopath);
            }
        else
            printf("\nNo path for Echo: %s",s[i]);
        }

    for (i = 0;i<5;i++) {
        user_pos = finduser(users[i],"c:\\opus\\user.dat");
        printf("\nPosition for user: %s is %ld",users[i],user_pos);
        }

    for (i = 1;i<255;i++) {

        msgpath = get_msgpath(i,"c:\\system\\");
        msg_attr = get_msgattr(i,"c:\\system\\");
        m_pos = get_msgpos(i,"c:\\system\\");
        filepath = get_filepath(i,"c:\\system\\");
        f_pos = get_filepos(i,"c:\\system\\");

        if (msgpath) {
            printf("\nMessage path for area %d = %s Attr = %x Pos: %ld",
                i,msgpath,msg_attr,m_pos);
            free(msgpath);
            }
        else
            printf("\nNo Message path found for area %d",i);
        if (filepath) {
            printf("\nFile path for area %d = %s Pos: %ld",
                i,filepath,f_pos);
            free(filepath);
            }
        else
            printf("\nNo File path found for area %d",i);
        }
    exit(0);
}


