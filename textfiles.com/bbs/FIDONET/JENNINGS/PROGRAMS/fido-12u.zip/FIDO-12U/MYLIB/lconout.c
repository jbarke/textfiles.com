
/* Type a character. */

lconout(c)
char c;
{
	bdos(6,c);
}
