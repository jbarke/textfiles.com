#include <ctype.h>
/*
;;
;;
;;int lconin();		Waits for a character
;;			from the console.
;;
;;int keyhit();		Returns null if no character
;;			available, else the character.
;;
;;
*/
/* get a character from the console. */

lconin()
{
	return(bdos(7));
}

/* If a key is hit, return the key, else 0. */

keyhit() {
char c;
	c= bdos(6,0xff);
	return(c);
}
