#include <ctype.h>

/* Find a substring within a string. Return its index, or -1 if not
found. Ignore case. */

short strfnd(string,pattern)
char *string,*pattern;
{
int i;
char *s,*p;

	for (i= 0; i < strlen(string); i++) {		/* unanchored search, */
		s= &string[i]; 				/* start at each char */
		p= pattern;				/* position, */
		while (*s && *p && (tolower(*s) == tolower(*p))) { /* search until */
			++s; ++p;			/* mismatch or */
		}					/* end of pattern, */
		if (!*p) return(i);			/* if end, found it */
	}
	return(-1);
}

