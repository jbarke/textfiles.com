#include <fidotime.h>

/* Get the current time. Do it repeatedly until it stops changing. (This
of course assumes that the get time routine takes less than one second.) */

void get_time(t)
struct time *t;
{
struct time x;

	do {
		x.year= gtod3(0);
		x.month= gtod3(1);
		x.day= gtod3(2);
		x.daywk= gtod3(3);
		x.hour= gtod3(4);
		x.mins= gtod3(5);
		x.sec= gtod(6);

		t-> year= gtod3(0);
		t-> month= gtod3(1);
		t-> day= gtod3(2);
		t-> daywk= gtod3(3);
		t-> hour= gtod3(4);
		t-> mins= gtod3(5);
		t-> sec= gtod(6);

	} while (x.sec != t-> sec);
}
