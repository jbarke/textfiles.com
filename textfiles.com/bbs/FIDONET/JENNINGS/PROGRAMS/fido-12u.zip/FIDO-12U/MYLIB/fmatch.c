/* Compare two file specs, see if they match. The first name is the
pattern, and can contain wildcards. Returns 1 if name #2 is contained
within name #1; i.e. name #1 == "ABC*.ASM" name #2 == "ABCDEF.ASM" */

fmatch(s,p)
char *s,*p;
{
char fcb1[12],fcb2[12];
int i;

	cvt_to_fcb(s,fcb1);		/* force into fixed field */
	cvt_to_fcb(p,fcb2);		/* for easy compare, */
	for (i= 0; i < 11; i++) {
		if (fcb1[i] != '?') {	/* if not a wild card, */
			if (fcb1[i] != fcb2[i]) return(0);
		}
	}
	return(1);			/* all chars matched. */
}
