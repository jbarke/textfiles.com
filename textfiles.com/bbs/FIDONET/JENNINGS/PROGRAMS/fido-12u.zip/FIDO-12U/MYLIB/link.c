#include <stdio.h>
#include <ctype.h>

/* Missing Lattice C function: File rename

	error= link(oldname,newname); */

link(old,new)
char *old,*new;
{
char fcb[36];
int i;
char *p;

	for (i= 0; i < sizeof(fcb); i++)	/* clear it out first, */
		fcb[i]= '\0';

	cvt_to_fcb(old,&fcb[1]);		/* first name, */
	cvt_to_fcb(new,&fcb[17]);		/* new name, */
	return(bdos(23,&fcb) == 0xff);		/* do it. */
}
