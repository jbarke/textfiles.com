#include <fido.h>

/*
	Fido Sofware program title block.
*/

copr() {
	printf("Fido/FidoNet %d%c\r\n",FIDOVER,FILEVER+96);
	printf("Copyright Tom Jennings 1990, 1989, 1988, 1987, 1986, 1985, 1984\r\n");
	printf("Fido Software, Box 77731, San Francisco CA 94107, USA. All rights\r\n");
	printf("reserved. \"Fido\", \"FidoNet\" and the dog-with-diskette are\r\n");
	printf("registered U.S. trademarks of Tom Jennings.\r\n\r\n");
}
