/* Extract function definitions. */

main(argc,argv)
int argc;
char **argv;
{
int file;	
char c,lastc;
int something,parens,brackets,comments,function;
int line, col;
char hdr[40];

	allmem();
	fastfile(1);
	file= open(argv[1],0);
	if (file == -1) {
		printf("File missing. Try EXTPROTO <filename.ext> \r\n");
		exit();
	}
	something= function= brackets= parens= comments= 0;
	line= 0; col= 0;
	lastc= '\0';

	while (read(file,&c,1)) {
		if (c == 0x1a) break;			/* stop if ^Z */

/* Dont count parens and brackets that are inside comments. This of course
assumes that comments are properly matched; in any case, that will be the
first thing to look for. */

		if (comments <= 0) {
			if (c == '{') ++brackets;
			if (c == '(') ++parens;
			if (c == '}') --brackets;
			if (c == ')') --parens;
		}

/* Now do comments. This properly handles nested comments, whether or
not the compiler does is your responsibility */

		if ((c == '*') && (lastc == '/')) ++comments;
		if ((c == '/') && (lastc == '*')) --comments;

		if (brackets || comments) something= 1;

		if (something && isalpha(c) && !function && !comments && !brackets) ++function;
		if ((c == '{') && function) {
			bdos(2,0x0d); bdos(2,0x0a);
			bdos(2,0x0d); bdos(2,0x0a);
			function= 0;
		}

		++col;
		if (c == 0x0a) {		/* newline == New Line */
			col= 0;			/* set column 0 */
			++line;
		}
		if (function) bdos(2,c);	/* display text */
		lastc= c;			/* update last char */
	}
	close(file);
	printf("\r\n\r\n");
	if (brackets) printf("Unbalanced brackets\r\n");
	if (parens) printf("Unbalanced parenthesis\r\n");
	if (comments) printf("Unbalanced comments\r\n");
}
