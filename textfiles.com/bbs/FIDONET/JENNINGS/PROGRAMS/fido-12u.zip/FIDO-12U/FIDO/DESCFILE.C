#include <ascii.h>
#include "fido.h"
#include <xfbuf.h>
#include "fidomem.h"
#include "proto.h"

/* Given a list of names, prompt for a description, and add it to FILES.BBS
in the current directory. */

void descfile(list)
char *list;
{
char *cp,ln[SS],fname[SS],buff[SS];
int f;

	makeuname(fname,"FILES.BBS");		/* upload FILES.BBS */
	for (cp= list; *cp; cp= next_arg(cp)) {
		cpyarg(ln,cp);			/* copy one name, */
		cpyarg(ln,strip_path(buff,ln));	/* strip off the path */
		if (! kfile(fname,ln)) break;	/* avoid multiple occurences */
	}
	f= append(fname);			/* open/create, seek to end */
	if (f == -1) {				/* somethings wrong */
		mprintf(CM+151,fname);		/* SORRY: Can't create..." */
		lprintf(LM+151,fname);		/* "cant create" */
		return;
	}
	mconflush();
	cmdflush();

	while (*list) {
		cpyarg(ln,list);		/* get next word, */
		list= next_arg(list);		/* next ... */
		cpyarg(buff,strip_path(buff,ln)); /* strip path */
		stoupper(buff);			/* make pretty */
		if (strcmp(buff,"FILES.BBS") == 0) continue;

		sprintf(ln,CM+10,buff);		/* "describe" */
		strcat(buff," ");		/* add a blank to the name, */
		write(f,buff,strlen(buff));	/* write name, */

		getfield(buff,ln,0,99,sizeof(buff)-2,0); /* get a description */
		strcat(buff,"\r\n");		/* add a CR LF */
		write(f,buff,strlen(buff));	/* write description */
	}
	close(f);
}
