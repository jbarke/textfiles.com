#include <stdio.h>



unsigned int14(unsigned, unsigned, unsigned);



unsigned

int14(ahval, alval, port) {

unsigned ahval, alval;

unsigned port;



unsigned aval;		/* INT 14 return value */



	asm {

		mov	ah, ahval

		mov	al, alval

		mov	dx, port

		int	0x14

		mov	aval, ax

	}

	return (aval);

}



