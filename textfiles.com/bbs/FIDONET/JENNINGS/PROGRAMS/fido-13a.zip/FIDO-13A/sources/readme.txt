Removed from service on 28 Oct 91

Unfortunately, the source is only half-way to Microsoft C v5.1.
All of the modules compile, but never got it to link (due to
library modules not re-compiled, etc). X/Zmodem modules not completed.
There may be problems with (Lattice) &struct vs. (M'soft) struct.
There will certainly be problems with printf().
The code is destined to be large model. 
This was post-v12u, and was destined to be v13.

FIDOTOOLS was not touched at all, and are still in Lattice 2.15. 

MYLIB and FIDOLANG are merely copies from 28 Oct.
