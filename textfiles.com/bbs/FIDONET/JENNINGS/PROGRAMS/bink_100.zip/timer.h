/*
	$Header$
*/

/*
   $Source$

		This file contains header information for the timer routines.
*/


/*
 * $Log$
 */


/* This union holds a long integer as a long, 2 ints or 4 chars */

typedef union
	{
	long l;
	struct
		{
		unsigned char c[4];
		} c;
	struct
		{
		unsigned int i[2];
		} i;
	} TIMETYPE;


#define PER_WEEK  60480000L
#define PER_DAY    8640000L
#define PER_HOUR    360000L
#define PER_MINUTE	 6000L
#define PER_SECOND     100L

