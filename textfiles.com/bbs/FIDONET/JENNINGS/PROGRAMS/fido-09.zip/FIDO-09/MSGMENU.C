#include <stdio.h>
#include <ctype.h>
#include <bbs.h>
#include <mail.h>

/* Message area menu. */

msg_menu(s)
char *s;
{
char ln[80];
char path[80],cmd,*p;
int n;

#defintfintfiMAI� chys-> mttrib & SYSMAI�ar r r 	hystem(0,enu
m);		ssaenud hystem inle,
msg	if c!h>
_paecked[enu
m]) ar 		mpr;
f("Mnu Aenu.#%u: %s %s\r\n",r 			enu
m,hys-> enu80],,(MAI� ? "(FidoNet)" : ""));r 		pak_h>
cha;		ssamenu,paeck ioh[h>
,
msg		h>
_paecked[enu
m]= 1; ssado
do every tis)

msg	}r r 	whnle c1) ar 		aboht= 0;r 		lntf= 0;r 		mpr;
f("\r\n");r 		stoup
r(hys-> enu80],);r 		mpr;
f("Mnu Aenu.#%u: %s %s\r\n",r 		enu
m,hys-> enu80],,(MAI� ? "(FidoNet)" :     us 	nug	lp uREGULAR	whnle      rib &chro0]t(&
,
m],)v,0t) nle  	ls chro0]t(&


],)v,0t) %s\r\= 0;r 		mpr;
f("\r}" :     us 	nug	lp uEXPERT	whnle      rib &chnle  80],);r 		m,
idot) hro0]t(&
,
m],)v,1t) %s\r} 	ls chnle  80],);r 		m
idot) hro0]t(&


],)v,1t) %s\r} %s\r\= 0;r 		,p?nu,pg	lpidot)("\r} 	ls nle      rib &c0],);r 		m,
 Co0
,ndidot)("\r 	ls c0],);r 		mpr;Co0
,ndidot)("("\restschyng(ha> enu80],);r 		mpr;mpr;
f("\rp;rskip_
t=m(ha> enu8    ",r_chgs(p&c<  	wc= 1);ue)("("\r\n"low 		pt)" : "0];rcm++f("\rp;rskip_
t=m(p
f("\rp;rschyp_hys-(hys->pt)("("
mW caescnu,p		eop-= lywc=0
,ndsnu,p	afstyveI  s- chr)vteesstc1}r d hys("cha );
c;
ccc/* i1}r cha;		icnisnpo* i1}r u,p("know}rdesc1}r i <scnn"80];nesst- mveT- yrsc h
 w= 1;estp		eopwc=0
,ndsveNscsst-acnnhisna* ,rys("t-acnah
 us 	wc=0
,ndsncha nscn",r 	icmenu. */u8    is_"0](80],&


],)v	w|| (80] =;r'?'	w|| (is <gic(80]	w&&  us 	nu],)v u= mttOPet&chnle  swic];(80]	whnle  8cas c'a':nle  88    is <gic(cmt&cn=I� oi(p
f("\r\r 	ls c(n=I-1t) %s\r88    

s 		nt&chnle  r88    
msg	if c!h>
_paecked[enu
  r88    cmt p;rskip_
t=m(++p
f("\r\r : ""));r 		p
f("\r\r : 
,
msg		h>
_paecked[en("\r\r :}("\r\r }("\r\r bha;k;nle  8cas c'i':nle  88m
#dd	p
f("\r\r bha;k;nle  8cas c'k':nle  88mk h
	p
f("\r\r bha;k;nle  8cas c'l':nle  88mt=sc	p
f("\r\r bha;k;nle  8cas c'r':nle  88m
m);	p
f("\r\r bha;k;nle  8cas c'e':nle  88ms dd	oN,0,0t) %s\rr bha;k;nle  8cas c'g':nle  88goodbye	p
f("\r\r bha;k;nle  8cas c'm':nle  88haturnf("\r\r bha;k;nle  8cas c's':nle  88    rib &chnle  8u80],);r 		----- MAI� ?  mtcts -----mpr;
f("\r\r\rus 	mshadic(
f("\r\r\r\= 0;r 		mpr;
f("\r\r\r\= 0;r 		Av,
c1}r MAI� ?  mssaens:mpr;
f("\r\r\rt=sc_ns
s(
f("\r\r\r\= 0;r 		------------------------mpr;
f("\r\r\}("\r\r \= 0;r 		nuare* Mess:[enn"u.u%u: %s


n"tcls


highesc
f("\r\r\stcts(
f("\r\r\""));r 		p
f("\r\r bha;k;nle  8cas c'?':nle  8cas c'h':nle  88    rib &chlp

		;r 	
f("\r\r\	ls chlp

		;

f("\r\r\bha;k;nle  8cas c'1':nle  88l= 0;r 		PATHchar =Aenup;.#%u: %shys->pt)("\r\r\shys-(h,hys-> enu8\r \= 0;r 		Waicn...mpr;
f("\r\r\;
c=unc(
f("\r\r\bha;k;nle  8cas c'2':nle  88maesc	p
f("\r\r bha;k;nle  8cas c'3':nle  88l= 0;r 		SETMSG ;.#%u: %sht) %s\r88    rib &cs c_r_

	p
f("\r\r 	ls cs c_r
	p
f("\r\r bha;k;nle  8cas c'4':nle  88l= 0;r 		SETMnu80har =enup;.#%u: %shys->pt)("\r\r\s c;r 		p,hys-> enu8\r bha;k;nle  8cas c'5':nle  88l=sc_ssg	d(
f("\r\r\bha;k;nle  8cas c'6':nle  88 0w_ssg	d(
f("\r\r\bha;k;nle  8

ault:nle  88m= 0;r 		'%c'nisnnscnawc=0
,nd%u: %s80]	f("\r\r\bha;k;nle  }("\r} 	ls c0],);r 		'%c'nisnnscnawc=0
,nd%u: %s80]	f("\}("}("
mAsknn"ussamenre* Mess );
nhisnaha;menu. */""));r 		pau(s)
char *s;
{
char 2];)

msg	}r r(n"low 		ha&c!;r'y'	w&&  n"low 		ha&c!;r'n't&chnle     us 	nug	lp uEXPERT	w\= 0;r 		Wantnn"ussamenu,paeck?n(y,ntidot)("\r	ls c0],);r 		Csamenr,
 (y,ntidot)("\restschyng(ha> enu80],);r 		mpr;
f("\r\;rskip_
t=m(ha> enu} inle,n"low 		ha&c=;r'y'	wl=sc

s(
f("s)
