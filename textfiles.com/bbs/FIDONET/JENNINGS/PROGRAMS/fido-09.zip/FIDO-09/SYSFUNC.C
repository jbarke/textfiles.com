#include <stdio.h>
#include <ctype.h>
#include <bbs.h>

/* Fielded input. Inputs are:

string		where to put the input,
prompt		the prompt string,
min		minimum number of words,
max		maximum number of words,
width		maximum string size,
cap		Remove extra spaces, capitalize, etc. Works
		only if one or two words.
*/

getfield(string,prompt,gmin,gmax,width,cap)
char *string,*prompt;
int gmin,gmax,width,cap;
{
char buff[82];
int i;
char *p;
	while (1) {
		place(0,0);
		cprintf("%s",prompt);
		clreol();
		getstring(buff);
		if (strlen(buff) > width) {
			stat("Too long");
			continue;
		}

		if ((num_args(buff) > gmax) || (num_args(buff) < gmin)) {
			if (gmin != gmax) {
				sprintf(buff,"%d to %d words.\r\n",gmin,gmax);
				stat(buff);
			} else  {
				sprintf(buff,"%u word(s)\r\n",gmin);
				stat(buff);
			}
			continue;
		}
		if (cap) {
			p= skip_delim(buff);
			stolower(p);			/* make all lower case, */
			cpyarg(string,p);		/* copy in 1st name, */
			string[0]= toupper(string[0]);	/* capitalize, */
			p= next_arg(p);			/* skip that one, */
			while (num_args(p)) {
				strcat(string," ");	/* separate with a space, */
				*p= toupper(*p);
				cpyarg(&(string[strlen(string)]),p); /* add 2nd name, */
				p= next_arg(p);		/* ptr to next name, */
			}
		} elsinclude 	cpt(string(buff);
	blrma);
	}}

/*Dis	plpyany iatgwerca dtoplrts 2ndaciads Tthevtauhe casded ts asnuded t
bey iatgweraciads 
*/
dtoplr ();
intnp;
{		cprintf($"%.n"ny/n 00p);		/*	woiledtoplrte, */
	if ((o n 00p) <10p)l	cotoat'0'");	/* makeaciadr twotdgiadr */
	cprintf("un"ny n 00p;/
	if n) <10000p)l	cotoat' 'p);		/* makeaco s(scia> widt, */
	if n) <1000p)l	cotoat' 'p)}}

/*	Rturn)stuhe	ifs1d ts	conarided wit ins2s Tt tsscidtsso* methotdasliiplr;
scmte,bput tsf ats Tthe0x5f* m sd ts s	rlude toupper)s 
*/
snb(stt(1,s2p)
char *1, *2p;
{
char(*, q;}

	while  *21) {
		p= 1);qp= 2);
		while  (r(* &e0x5f1)==e  q &e0x5f1x) || (* ==e'?'1x)&&r(*)) {
		++*p ++q;
{
char(*, q;}

	while  	p= \0p) rifs1dace, q;}r(e  (r(

rifs1da0turn)stuheD swuppbo;		iacn
prof/
,g2srplrIt t
bey ias*/
		it t
bstriinthg0x5/
		/'he irycap	slid swstt(1,s2bo;(slgws2slrotws2s{		cprslgws2slrotws2s*, q;}r *p;
		cprslg,llrot,l  *21)slg,lp=0 (r(rot,l=
,cp -oa  *21)
		cpslgws2slslg,le, q;fs.(i= rot,l -oslg,lhai--;'p)}}

/e,y zb
e, q;
		cprotws2slslg,le, q;fs.(i= rot,l -oslg,lhai--;'p)}}

/e,y zb
e, q q;fs.(i= slgws2shaiot= rotws2shair(e(0,0);
		cpilslg,le, q;	)}}

/acrtb
e, q;;
		cpilrot,le, q;	)}}

/acrtb
e, q;}21)
		cpslgws2slslg,le,p)}}

/ul,�}

/ac          �		getstrin�֡�    wit in�l
e, q;;
	);