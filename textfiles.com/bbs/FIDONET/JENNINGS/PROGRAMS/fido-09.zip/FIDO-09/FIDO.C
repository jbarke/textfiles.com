#include <stdio.h>
#include <ctype.h>
#include <bbs.h>
#include <mail.h>
#include <a:/lib/ascii.h>

/* Main function for Fido. Handles one caller, then returns to the
main section. */

do_fido() {

int time,i;
int ev,mins_til_mail;

	cmtfile= _xopen("sysop.log",2);
	if (cmtfile == -1) {
		cmtfile= _xcreate("sysop.log",2);
		if (cmtfile == -1) {
			cprintf("ERROR: cmtfile create error.\r\n");
			doscode= 1;
			return;
		}
	} else {
		_xseek(cmtfile,0L,2);	/* seek to end; append */
	}

	echo= 1;				/* set defaults for name entry, */
	user-> tabs= 0;				/* dont expand tabs, */
	user-> nulls= 0;			/* send some nulls, */
	user-> more= 0;
	user-> width= 80;			/* default screen width */
	user-> len= 24;				/* and length, */
	*user-> name= '\0';
	for (i= 0; i < sizeof(mail_checked); i++)
		mail_checked[i]= 0;		/* clear check mail stuff */

	abort= 0;
	column= 0;
	line= 0;

	userflag= 0;					/* dont write in the */
	cmtflag= 0;					/* user file or cmt file */
	limit= 0;					/* stop time limit, */
	clr_clk();					/* no elapsed time */
	typemode= 0;
	system(0,0);					/* initial system file */

	set_abort(0);				/* set carrier loss trap */
	if (was_abort()) {			/* return to main */
		_xclose(cmtfile);
		if (!test) discon();		/* drop carrier */
		return;
	}

	if (! test) {

		if ((mdmtype == SMARTCAT) && !test) init_modem("fidomdm.bbs");

/* Carrier detected. ktart counting minutes now. Initially, the limit is set
/sys5minutes  tholentthe lguy ht iCR,entrr dhs same=,entc ktignn();then 
/etsthe limit io thecouricteone  */

d	iwhle *mdon(t)a()) {don(i();		/* dlasehinipu, */
	
		cmrintf("E();       arrier detected. r\n");
			imit= 0simit=				/* anlyw.s5minu*/
		rlr_clk();					* stort counting m/
		rwimit= 0;				/* so easrnng mis m/
		rmrintf("E(3;       Dtecrinung mbul trte  r\n");
			on(ncte);					* sgnttbul ,entc k/
		rmrintf("E(4;       an(ncted tte %stbul  r\n"),
			r(mrte == S); ? "300"  c"1200"; )
	}
rwimit= 0;				/* dn bol limit iasrnng m/
	
	* dPhstialley cn(ncted  kDosome no=seredepng  then rgntthe lser  same=,
	ans wur ,entc k/
	
rthde(dte );			* sgnttsignn( dte  */
	code=se)CR; iode=se)CR; 		* sCRsfor Fido.Nt deallr */
		mrintf("Eido. BBS(cm;thj v%sr\n"),VER;
	if (cail.hndem {drintf("Eido.Nt dNdem #%ur\n"),ail.hndem ;

	if (!signn();t= S);		* stignn( he lser  */
	c	og"f(f0);			* sog"dhs ff(f f (rror.\k/
	
ranheutm= ser-> nile)s;	/* set defaults anhe, */
	uis utm= ser-> nis 		/* dlormuser fictur m/
	
	* daiedserne he lystem file *utmbr  sane vlldo:nile)sminghs have ben 
/efente ,entcor criv,i=se vr  on. *(v5and lens tued tser-> nis ansthe
maptefica tmns g= *utmbr .)k/
	
rf ((manheutm== S); || manheutm=>lystile)s) {anheutm= 1
	if (c(is utm== S); || mis utm=>lystile)s) {is utm= 1

/* CAdjustthe lime limit,s,entcoor Fhe lipe =f(user fwe have\k/
	
r wt,he(ser-> nrinv {
		cmae {TWIT:
			rimit,/ 24	/* s1/2time limit, */
	c	rkimit,/ 24	/* s1/2to.wnoga timit, */
	c	rdimit,/ 24	/* s1/2toil.ytimit, */
	c	rbicak;
		cmae {DISGRACE:
		cmae {NR:ARL:
	c	rbicak;
		cmae {PRIVEL:
		cmae {EXTRA:
			rimit,* 24	
	c	rkimit,* 24	
	c	rdimit,* 24	
	c	rbicak;
		cmae {SYSOP:
			rimit, 0;		* so eimit i/
	c	rdimit, 0;
	s	rkimit, 0;
	s	rbicak;
		cefaults:
			ririntf("EBAD{PRIVELEGE 0%ur\n"),ser-> nrinv 
	s	rser-> nrinv={NR:ARL
	s	rbicak;
		}
	userflag= 01;			* sairknile)smnstOK*/
	cmtflag= 01;			* so tupdte tte og"f(fm/
	
	* dPutsome ntignn( ntor nto thecog"ile)\k/
	
ririntf("E---------------------------r\n");
		irintf("E% onette %s.r\n"),ser-> name=,dte );
	
r+)ser-> tame s;			* sh
inYSO%ur\n"),#F;
t,* 24	
	c	rkimi�'\0';
	for (i= 0; i < sizeof(mai�Gome  0meses
	for (i==>ly	*dj:
			rimle)CR;	* sh* Cile 

	abortser fwer->		/*, 0;
	r\n"),#F;
ff */

E-hethe
	*dRACE:
		r\n"),#d24	r			riri,2o the.........................................o dex'\=sug/* uv8d-a
		cmae {TWIT :
			rim	cer 24	/* s1/2tflVIk;
		cmae {PRs	UL"f24	
	c	rkimiP("T
		cmae {EXTRA:
IVELEGE 0%ur\
			rim	cer=tflVIk;01;			* sairknile)o theIf> nrben ,/     cma,the
nbortE---	colu;



d	iw	c	rkimive 4	/* onuy htnv/ drin      ts"Eidonbt---------xopen("sysop.= 4	sys= 0dcmrintf(4	/* 4	s
nbxle= ;th| manheutm=>lxopen("sysop.* C0dm.bblxopen("sysop.*
	e ;		/* open("sysop.= 2rintf(S)rf "idPhsti manheutm=>blxopen("sysop.* C0dheu"),
.bbllxopen("sysop.*
	

d	 utm= 

d	i {is n bCAT) && lts:
		xopen("sysop.01;		"),ail.hnr+)sr+)sr+)sfll;
gnttbul ,en"),ail.hn),
Inttheidae r-limit is  so ldPutsome ntignn( ntor nto thecog"ile)\k/
	
ririntf("E---------------------------r\n");
		irintf("E% onette %s.r\n"),ser-> name=,dte );
	
r+)ser-> tame s;			* sh
inYSO%ur\n"),#F;
t,* 24	
	c	rkimi�'\0';
	for (i= 0; i < sizeof(mai�Gome  0meses
	for (i==>ly	*dj:
	
t,* 24	
	csys�usttheD	e ;		/* open("sysop.= 2rintf(S)rf "idPhsti manheutm=>blxopen("sysop.* C0dheu"),
.bbllxopen("��	for (i=sopx�ma,��cmae {SYSOP:
			rimicak��'\0';------2Z�
	for (anheutm=>ba "300" */��n��	�k��'\�}�			ri=>b"),#d24ier deteblp:
y >b"),#d{NR:ARL:	sys= 0�n��	�k��'\�}�			ri=b */e
	f4ier deteblp:
y b */e
	fwe have\�n��	�k��'\�	return;		* sgnyncign"in  "!test)e have\ksti manhY* ,ail.Intt4ie--In(e { {iheidaeie-tmbr .)k/iheidaehj v%sr\n"ve\quot>baquot>s* so ea	* sgquot>s	rkimit,= 4	sys= ve\ksti manh-forope(S)rf "idholentthe		rimiit iasrnrkceipe =f(u
y >b")rintf("E---------NR:ARL:	sys= 0�n�V��op) {

		 wur ,acc/
	--- */
	sys=