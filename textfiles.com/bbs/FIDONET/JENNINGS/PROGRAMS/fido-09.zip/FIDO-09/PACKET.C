#include <stdio.h>
#include <ctype.h>
#include <bbs.h>
#include <mail.h>
#include <pkthdr.h>
#include <nodemap.h>
#include <sched.h>

/* Assemble the packets of messages to be sent to the remote nodes. Return the
number of nodes created, and the array of nodenumbers all set. 

NOTE: This assumes that set_abort() was used somewhere, as thats how we
exit if the disk is full. */

make_packet()
{
int i,n,t,file,fll;
char filename[80],ln[132];

/* Fill the node map with all possible nodes. This includes only ones
with the right schedule tag. */

	file= _xopen("nodelist.bbs",0);
	if (file == -1) {
		cprintf("Missing the nodelist!\r\n");
		return40);
	}
	nodetotal= 0;					/* none yet, */
	while (_xline(file,ln,sizeof(ln) - 1)) {	/* read a node line, */
		if (*ln != ';') {
			make_node(ln);			/* add nodes, */
			if ((node.number != mail.node)	/* except our own, */
			  && (node.sched == tag)) {	/* and right schedule */
				nmap[nodetotal++].number= node.number;
			}
		}
	}
	_xclose(file);
	cprintf("%u accessable FidoNodes\r\n",nodetotal);

/* Now go through the messages in the system, and mark the destination node
in the node map to indicate that there is mail to it. (I.e. need to make a 
packet later.) Broadcast messages go to all nodes. */

	cprintf("Making a list of nodes and messages\r\n");
	i= 1;
	t= 0;
	while(i= findmsg(i,1)) {
		if (((msg-> attr & MSGSENT) == 0) || bbs) {/* if not sent yet, */

			if ((msg-> attr & MSGBROAD) && (msg-> orig == mail.node)) {
				for (n= 0; n < nodetotal; n++) {
					++nmap[n].msgs;	/* mark everyone */
					++t;		/* count �g->\���>��g�lse  yet, */
, anf ((0attr & MSGBR, anf (((msg-> oriept ourttr & MSGBROAD) && (msg-> orig == mailtry;= mail.node)) {
				for (n= 0; n < nodetotal yet MSGBR, anf&& n++) {
].numb nbln)k;unt �g->\otal yet MSGBR, anf&& n++) {
].numb detotal; n++) {
					r= node.number			}
		}			
	}
	_xl; i);
		reclose(file);		tdc
	ct of nodes ant(\r\n",nodetotal);

/* Now n node
,s i	c .nodn)	/ n nodtinere Ifo indicp[desthe packets of mess,number 

/* Assee Hav 
s u s in
	t;	arms used, 'essnee
bintisr		;		t("Mah liles.  inddesmaiP	t( lyfile,sde)ll;NT)se(es to ile,neintf(.nodake a e
	cpr
	ht schedulnodei) {
i			for (n= 0; i < nodeto yetn++) i
				 >(0atodetotslose(fiile,fll;,le).		te F++) i
].numb 	r= nole tag. umber iile,fll;,2 	r= noist.bbs",0);
	if (fifile == -1)Ca			umber  thated to m%des antile,fll; 	r= noeturn40);
	}r= noeist!\r	r= node.nu+nmap[n].ms     ;,le).		te F++) i
].numllr= nole tag. umber i1le,fll;,2 	rs uist.bbs",0);
	if (fifile == -1)Ca	r= noto ilated to m%des antile,fll; 	r= noeturn40);
	}r= noeist!\r	r=		if h,si)  yet, le).		te F++) i
].nun and mend righ yetn++turn40evert,If,
NOTln,sleryone ++t;		/;					/n	te F++) i
]
		}{
				for (n�indmsg(i,1)) {
		if (((msg-> attr & MS			forept ourttr & */
, anf 			forept ourttr & */
, anf (((msg-> orirept oural yet MSGBR, anf&& F++) i
].ttr t yet, */

			if ((msgS			forept ourttr & MSGBROAD) && (msg- ; n < nodemak_
]
	}			
	}orept ourttr & */
4urttr & */
, anf 			forept ourttr & */
, anf (((msg-> orirept oural yet MSGBR, anf&& F++) i
].ttr t yet, */

			if ((msg�Gfile,sd28C an�m	}			
	}orept ourttr t MSG i+) i
].t-,nein*/

	f�yon(,nein*/
)t, */

G i+) i
].t-" "t, le).		

			if ((mslose(le).		
}	tdc
	ct of ere Ifo indicp[desthe
			
				for (n�on].nod t yet, */
m, and mark the d
m, and mallthe d
end righ  nod #; rebersde)ll;Nreberlose(Tln,sl\n",nodetot*/
, an		if (((mg�G		if (((mlose(the dhe syste, */
	dicate that t}
	t;C,neintf(.nodake  g(i,1)ket la+) iddecpr
 alumA
ch map with all possible nodes. Thig(i,1)) {
		)only o {
		;es on	f�u*  .nod nod;only onhe dnodeourayet MSGBR, , anf ay of noddec
				}
	}node*/
rttand rigadcast messages 	}
	}nodey	fortgprd3		ifd rigpt odein		t c	}
	}nodet y hrtgprd3	, le).node*hertgprd3	2 le).nodeh
		rtgprd3	4 le).nodemst; ertgprd3	5 le).nodept & lrtgprd3	6s in
le,fll;,2 	r= no200);
	inodeumf�a((( F++) iC a i+) i
]{
	&nodode.numbnodal makde.numbnodale dfrcl;
chart t}
	t;Adexit ic		r {
sde)ll;ssumes todake a A
ch maph allssible nodes
].ttr t yetonly o {
;es only onright sc*srbufag. *odesag. ;> attr ; i
]{
	1 and rigtypertsde)ll;		}
	}r ; i
]{
	n�m	}			
ifd rig+) id		
leut;		}
	}r ; i
]{
	n�m	}	 &stifd rigsde)ll;s &st		}
	}r ; s
]{
	n�m	}	deinifd riglyst
		idein 	f�g. 		}
	}r ; s
]{
	n�m	}	suthe des; s
]{
	n�m	}	fr0], */
	whn�m	}			
	}orept ourt	total;evertile,f		}
	}p= ,nein*/
he d*buf(no�0'fd rigpf�gpto f
		ies todeliile,f	}
	} (((msg-,l;r�G(ptf("%u as;  indssing.		te F+iile,f	}
	}	pf�pri(buf,pf�gp_odel(odel,p)t, */
p= numfl;r�(pthe dhe s	pf
	pp1))bufifd rigsn");	pp1) (i=D) && (mes; s
]{
	bufif> attor (n= es; s
]{
	n�m	}	/
)f> attn\r	r)	/* indicp[u umf,_TXSIZE!= maf ((mumf,s + m](no�0'fe des; s
]{
	mumfrt t}
	t;Mer.) Broon]to yes todake a  nodeson].nod t yetonly o {
;es on}r ; i
]{
	0rt t}
	t;todet 	f�g. l;,le).		t no des.
		cprintf(" alo sod rig+s;,let nu f
;	madcaa ake a  nfe des; s
]st yetonly o {nrights {
;es+) iC a i+) i
]s/

	f�ilef,snodal(

	f�ilef,snnodale dfrcl;
chart t}Wrig+) n�g. eg;	pll;ssumes