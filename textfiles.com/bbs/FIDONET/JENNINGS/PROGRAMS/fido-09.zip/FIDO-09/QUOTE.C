#include <stdio.h>
#include <ctype.h>

long _fsize();

/* Given a filename, randomly pick out one parargraph and type it. Paragraphs 
are assumed to be delimited by a C� LF C� LF sequence. Return 0 if no quote 
found.  */

quote(file)
char *file;
{
long size,pos;
int handle,i;
char time[20];
char mark[5];
char c;
int start,stop;

	size= _fsize(file);		/* get file size, */
	handle= _xopen(file,0);		/* open it, */
	if (handle == -1) return(0);	/* doesnt exist, */

	gtod(penze(file* dondomlyo ed dr*/
	ifs;-1ad(i(&me[2011]re+ha60L/1ad(i(&me[2014]r

fs;*-1ad(i(&me[2017]

fs;*-132Lile* doGUESS:art e[eduote 
ze, */
	has;%=
ze, ile* dobnd. t, */
	ifopquekandle =os;);		/* opndomlyoquek*/
	if, rcpy(rk[5,"XXXX"		/* opdoythi sib on LF C� LF se
	if, t,s=
0ile* do qstart,spefuote 
ye */
	ifop;=
0i
	gtwhe si(optuadandle =o&c, re&& !op;re
loe*unc;(i=
0it,ct 4it,++)* doshefspevdr*/
	ife*rk[5]i]=ark[5]ie+h1
che*rk[5]3]=ac	/* op pw ar caypdr*/
	ife (ha, rcmp(rk[5,"\r\n\r\n"	= -10re
loe*e (ha, t,s) op;=
1/* do no qsp1son LF C� LF s*/
	ife*imif, toe do qse, *ote 
ye
	ife*imi[5prtarf(\n\r\n"	=Q
ye ;(i= simiay:n"	= -;e*imi[,s=
0il1;e*imi}e*im}e (ha, rcm) op;mcizne (c-;e*i}e (5prtarf(\n\r\ -;e*iua <;	ele =o&c-;e*in(0);	/cm) op;e