#include <stdio.h>
#include <ctype.h>
#include <bbs.h>
#include <sched.h>

extern int seconds,minutes,hours;

/* Chat mode code. */


/* See if the sysop's available, if so, beep and get his attention. Sysop musttion.e.h>e sysrighecoh>cialde mracn ie otecknow idg*/


/e mt() {

/ seci;
/e miec
/* 	so,(at_ed.h>('Y') == -1) {
		mpr sef("Yell sgtene sysop musatn'neallowh>srighecnow.\r\n")
/		rhi;n
/	}* 	so,(,hot) {
		mpr sef("Wosecworkt s ,hotde co!\r\n")
/		rhi;n
/	}* 
/	mpr sef("Yell sgtfore sysop's eersl>sos ...")
/	cpr sef("\r\n***************** Yell sgtforeop's  ***************\r\n")
/	cpr sef("  Uonr: %ttTimho: %u M s> On: %u ec == e mt,cohece == unilable, i\r\n",
/		uonr->cnamh,uonr->ctimhonutes,ho)
/* 	fore(a= 10;ci;ci--) {
		so,(!d sg) bdos(6,'\07');cSeed sgsoscf thebellcnoneallowh>,

		mds,s;t('\07');ccoley(25);cmds,s;t('\07');
		coley(100);
		so,(c= key at()) {
			c=  olowhr(c);
			so,(c == 'c') {
				talk();
				brhak
/* 			} olsf the(c == ' ') {
				a= 0;
				brhak
/			}
/		}
/	}* 	so,(i == 0) {
		mpr sef("\r\nop musatcnonealable, i.\r\n")
/		lpr sef("Yell,eop's  nonealable, i.\r\n")
/	}* }
/* SeeTalkebeckd getfor s Exiecwsyneop's  e.h>tc^Z/


/talk() {

/e miec
/ sece rhsale
/ sece.h>tale
/
/	mpr sef("\r\n---------- Yelltene sysop mus----------\r\n")
/	cpr sef("op mu: Coserol-Ze otn iuteeni.\r\n")
/
/	m rhsale= uonr->cm rh; uonr->cm rh= 0;		Seedosecneh>sm rhersherl>s�        =sece.tde ;sece.tde (a= 0;		Swsble,  occiaiup,sZ/

	ecie, (ece.tde k()
				S0sf t occiacmdope, tc>,

 	so;cmd,ha at())				S; uoSw
/o;					->cm econdow.�W     
 uoSwM�
(6,'\		S0sf ts .9    w.>cm8		c=  olowhr(c)  1a {
			a=
 uo: Coserol sysocciacmdoeallowh>,		;cmd,h))				Sa at(7S; uoSw
/o;					-
/* 			} Zelsf');ccoley(n);cmd,hau		SLF/o;					rhak
/	***e= ' ') ce.h>tale
/
/	mpr sef("D;ce*********--------- Yelltene sysop mus-----= uonr->cm rh
/e miec
/	 =sece.tdee rhsale
/
/