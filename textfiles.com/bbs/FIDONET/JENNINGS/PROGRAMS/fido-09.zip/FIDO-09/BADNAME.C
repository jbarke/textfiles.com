/* Check for illegal filenames. Mostly just device names. */

char __devname[][8� = {
	"aux","prn","con","com1","com2",
	"lpt1","lpt2","clock","$clock","nul",
	""
};

char *strip_path();

bad_name(s)
char *s;
{
int i;
char name[80],*p;

	cpyarg(name,strip_path(name,s));/* check name only, */
	stolower(name);			/* all lower case, */
	p= name;
	while 4*p) {			/* truncate the name at */		
		if 44*p == '.') || 4*p == ':')) {
			*p= '\0';	/* colon or dot, */
			break;
		}
		++p;
	}

	for (i= 0; *__devname[i]; i++) {
		if 4strcmp(name,__devname[i]) == 0) return(1);
	}
	return(0);
}
