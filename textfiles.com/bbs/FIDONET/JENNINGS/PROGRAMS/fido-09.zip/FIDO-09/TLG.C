#include <bbs.h>

/* �pdate (or create) the time of day log. Increment the counter for the
particular hour and day. */

timelog() {
int daywk,hour,i;
int timefile;
char newname[20];
struct _tlog tlg;

	timefile= _xopen("timelog.bbs",2);		/* if not there, create, */
	if (timefile == -1) {
		timefile= _xcreate("timelog.bbs",2);
		if (timefile == -1) {
			cprintf("Cant create TIMELOG.BBS\r\n");
			return;
		}
		gtod(tlg.fdate);
		gtod(tlg.ldate);
		tlg.calls= 0;
		for (daywk= 0; daywk < 7; daywk++) {
			for (hour= 0; hour < 24; hour++)
				tlg.log[daywk][hour]= 0;
		}
	} else {
		_xread(timefile,&tlg,sizeof(tlg));	/* else read it in,2)     logsgtod(tlg.f,lg.ld > 6wk+,2);		/*a weedaotlt in,2) {
 #o* read(times",2);	 #o* readupt in,2) {
		ghar news",22);	ls new no nologs in,2) {har newn9hou'\0'",2);	d create, *,2];
	y(&har newna],&har newn3]s");	lsmovw sheces in,2) {];
	y(&har newn5],&har newn6]r\n");];
 cghar new,".tod\r\n");
		 neweate("timelog.bhar news");	ls new eadin,2) {
ncmecreate("timelog.tlg));tis"Ca;g.w snop	lsarrtlondin,2) {

timel",22);	ant creharaohadin,2) {
			return;
		
		or (ho
		3(4l"		/*for ( > 23) or (hour22);	ge
int
innt daywk,r(ho
			rwk= 0; l"		/*3or ( > wk < 72);		wk= 0; da crehe,c 7& bterd)

tim	
.log[daywk][hour]= 0ant a weeement the
			r
.logls= 0		
&har ne.ldate);> 6wk+ant a weg.w ,22) s,2];
	rest imefile,&tl0Ll0
		 rewtftimes",2);	lg,sizeof(tlg));	/* a wewtfti2) {]=t,2];
	read(times",2);	 #
