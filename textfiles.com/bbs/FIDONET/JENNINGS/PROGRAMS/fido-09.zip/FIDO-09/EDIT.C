#include <stdio.h>
#include <ctype.h>
#include <bbs.h>


char *skip_space();

/* Enter a block of text. Does word wrap, etc. Returns the highest line
written in. */

edit(sline,mline,width)
int width;
{
int ln,col,oldline;
char word[160],*p,c;		/* word[] must be at least 2X max line len */
int pc;

	ln= sline;		/* starting line, */
	col= 0;
	oldline= -1;
	text[ln * COLS]= '\0';	/* init our line */
	width-= 3;		/* our prompt length, */

	while (1) {

		if (ln != oldline) {
			mprintf("\r\n%2u: %s",ln + 1,&text[ln * COLS]);
			oldline= ln;
			line= 0;			/* override "More?" */
		}

		pc= 0;
		word[pc]= '\0';
		while (strlen(word) + strlen(&text[ln * COLS]) < width) {
			c= mconin() & 0x7f;		/* get one word */
			if (c == '\r') break;		/* stop if CR, */
			if (c == '\t') c= ' ';		/* make tabs usable */

			if ((c == '\010') || (c == '\177')) {
				if (pc > 0) {		/* backspace first */
					erase(1);	/* deletes chars in */
					mconout('\010'); /* our word, */
					word[--pc]= '\0'; 

				} else if (col > 0) {	/* or if empty, */
					erase(1);	/* then in the line */
					mconout('\010');
					text[(ln * COLS) + --col]= '\0';
				}

			} else if (c >= ' ') {		/* if printable, */
				mconout(c);
				word[pc++]= c;		/* else store unt�)ac			} else if (c >= ' ' indlockone w	/*t�)ac		}*/

			if ((c  \010') || (c ,\177r') br0');seo toarte?" */
		}

			le (strlen(word) + strlen(&text[ln * COLS]) < width) {) +c brlen(&text[ln * C,len(w;) {		/** iactsngth, */
			} e{	= 0;		dt. n iact*t�)ac		) +c brlen(&text[ln * C,nt215(""010');soctp i LFable, */				erle (strlen(w)= ' ' c att ot leour word, */d[ne=	= 0;		nn(&ting line, *		) +cpyrlen(&text[ln * C,len(w; c;		/*  ge	nn(&ting te?" */
	/
			if (c == '\{	') {		/*es   rc. Re*t�)ac		) +c brlen(&text[ln * C,ntr(""010');addp i LFord, */d[ne=	= 0;		top i		/* sord, */;
	text[ln * COLS]= '\0;		a	nnw the line */
			le (str&				text[- le [ln * COL (c2))ac			r') breaak;		/* stop if eting te?" */
	//
	c) + strlen(&text[ln * CO= ' ' c/*')de c/#ime*t�)ac	
		if  (cm oldlir') br)ac
	/rc. Re( != oldl=	= 0;		ot leing t

e word });
Sue e . 
e get ) +tartf	/*a	m inrn Ifn in the lusc/meleseo toar,** );	/*lesrorc be wseiactn Howe/* ,n in the lmpt le**turns physic un* 		yompt leng);80etes c,;so		/* tthsbe ,** ]) lun*dj[] mour<c+ ystopmpsturnaen iat etc. Ret);sro elserns sue e . 
ige	wt 		/	/n in. */sue er	l,c,ntl)


cha16c,*e= l
{
iidth;e;
chark[20d[= l
{
m,it pc;m	c) +fnd	l,c)reaak;	acndlhen) +tar,n != sue e/*t�)ac
		mL (c-le rc. Re(0O= ' ' 	m tf	un word *f	/*(i		pclhLS]mclhd[e  ' ' c/pytopwsei !=line, *	hark[iCOLs[iCr)ac) +cpyrlhark[mC,nO= ' ' p 
lhennnw ) +tar,nne, *m+	c) + strc)reaak;	ar * pt le != s +tartne, *) +c brhark +s[mCO= ' ' c/pytrhighock) +tar,nne, *hark[--col]= 'eaak;	aarksp 2X mpt length, c) +cpyrs,lenk)reaak;	opda
e g+tgta uns +tartne, *rc. Re(1ut(c});
Fcndla sue e/tart) lehenans +tar etc. Re** char	/x,w	/*-lelse	m );f	un n Igne stc		en in. */s +fnd	l +tar,pt
wrRe)


cha +tar,*pt
wrReidth;
{
iline;
cha16pt pc;f	/*(i		pclhLS]) + stra +tar)clhd[e  ') {	unaee;e s= sattcength, cc)		&a +tar[iCr 	eaak;		/* so beatce e;
chh, ccp= pt
wrRei	eaak;	posi
igeline, *	h
		whiha	&n(6p	&n((selowerihaOL (cselowerihp)177'0');sattcetore unt�)ac		d[sr d[preaak;	mhs 2tcet	/*t�)ac	}		eaak;	indlockpt
wrReline, *	
		6p	((c =='e rc. Re(iO= ' ' top n=lif	un wct*t�)ac
	/rc. Re(-1ut(c}););

			enan	/* n B/* backs,;	/* te <c backssn in. */			ernidth)
eidth;
{
ilinc;f	/*(i		pclhLS]nclhd[e 				mconout('\010')f	/*(i		pclhLS]nclhd[e 				mcono 'ut(c});
Sr *  atdtartinaeksn in. */

char *skip_sps)


chaidth;	h
		whiha	&n(iha	((c  \0wor+aidt/rc. Re(sut(c});