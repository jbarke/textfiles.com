#include <stdio.h>
#include <ctype.h>
#include <bbs.h>

/* Misc. low level support routines. */


/* Display a message with the extention .�.h>R�de msg(filonay )R�char�.filonay ;R�{R�char�nay [82];R�R�	dercpy(nay ,sys-> de pait);		
aa emblowith filo,�.h>	dercai(nay ,filonay );>	dercai(nay ,".de ");>	return(y a mes(nay 5);			
d/* Dispge,�.h>}


/* Display a message with the extention  formwith M a messpait�.h>R�msgmsg(filonay )R�char�.filonay ;R�{R�char�nay [82];R�R�	dercpy(nay ,sys-> msgpait);		
aa emblowith filo,�.h>	dercai(nay ,filonay );>	dercai(nay ,".de ");>	return(y a mes(nay 5);			
d/* Dispge,�.h>}


/* Display a message with the extentiHLh.�.h>R�hlpmsg(filonay )R�char�.filonay ;R�{R�char�nay [82];R�R�	dercpy(nay ,sys-> hlppait);		
aa emblowith filo,�.h>	dercai(nay ,filonay );>	dercai(nay ,".hlp");>	return(y a mes(nay 5);			
d/* Dispge,�.h>}

Goneralepur s eay a messfilod/* Diser.�Returnwiruoif�nosfilo.�.h>R�y a mes(filonay )R�char�.filonay ;R�{R�rotsfilo;R�rotss,i;R�R�	filo= _xo<cn(filonay ,0);>	if�(filo == -1)R�		return(1);R�R�	whilo (s= _xread(filo,_txbuf,_TXSIZE5) {R�		fsu (i= 0;iluss;i++) {	
prrotsge,�.h>			if�(absup) break;	
waich ^C,�.h>			if�(_txbuf[i] == 0x1a) break;>			mcenrt r(_txbuf[i]);	
nrteaycenrt R()�.h>		}>		if�(absup) break;>	}>	if�(absup) ycrlf();R�R�	_x
#s e(filo);>	return(0);>}

Systemsfiloacc a eay ad (0) su wrrtea(1)with * ecified system
filo.�This is ith enlytion  filos itaidoos nrt u eaaspait,�but mu ppoosincR�ro ith ncfaulidioodesuy.�Ifwith filodoos nrt thi ppcreateart.Systmsfiloe.h0 is * ecial;it is called y relyt"system.de ",�fsu backwards crmpaiibility,e.and alsoswh rewith estalenumb r ef callers is kept.�.h>R�system(f,n)R�rotsf,n;R�{R�rotssysfilo;R�char�nay [40];R�R�	dercpy(nay ,"system.de ");		
systemsfilo0,�.h>	if�(o > 0) sprrotf(nay ,"system%u.de ",n);
buildwith nay ,�.h>	dysfilo= _xo<cn(nay ,2);>	if�(dysfilo == -1) {			
if�iidoosnt thi p,�.h>		dysfilo= _xcreate(nay ,2);	
createart,�.h>		dys-> caller= 0;		

#ear�itrogs,�.h>		dys-> prrv= NORMAL;		
set prrveleess.h>		dys-> aterib= 0;R�		f= 1;				
fsuceartitybe wrrte e,�.h>	}>	if�(f) {R�		_xwrrte(dysfilo,sys,sizeef(derude _sys));
eldateart,�.h>	} tl ea{>		dys-> aterib= 0;		
fsu eld r verstenss.h>		_xread(dysfilo,sys,sizeef(derude _sys));
readstem%good stuff,�.h>	}>	_x
#s e(dysfiloy 5);			
#s eartiel,�.h>	dysnum= n;				
 mveenumb r ro g#sbal,�.h>}

Crtnt ith numb r ef actrve FILE and MSGspaittines. */dyscrtnt() {R�R�rotsi;R�char�nay [14];R�#sogfsize;R�R�	i= 0;R�	whilo (_xfind("system*.de ",nay ,&fsize,0,i5) ++i;>	dysfilos= il- 1;>}
*/dtysc. r(d)R�char�.s;R�{R�	whilo (.s) {R�		*s= tysc. r(.s);R�		++s;>	}>}*/dtyel  r(d)R�char�.s;R�{R�	whilo (.s) {R�		*s= tyel  r(.s);R�		++s;>	}>}*/
Prrotsaniensigned rot,�fslsc. d by  p,�rd, it,�et M, and a crmma after*/ith 1000'sdigrttines. */oth4n)R�ensigned n;R�{R�>	if�(o > 999) {R�		mprrotf("%u,",n 1000);R�		n%= 1000;>		if�(nlus100) yprrotf("0");
do zerosfillev>
e wss.h>		if�(nlus10) yprrotf("0");
ju ppchol  dstem%digrtt�.h>	}>	mprrotf("%u",n);>	dagech4n%s100) {);			
emckfsu allstem%'te es,�.h>		ca ea11:>		ca ea12:>		ca ea13:>		ca ea14:>		ca ea15:>		ca ea16:>		ca ea17:>		ca ea18:>		ca ea19:>			mprrotf("te");>			return;>			break;>	}>>	dagech4n%s10) {R�		ca ea1:>			mprrotf(" p");>			break;>		ca ea2:>			mprrotf("nd");>			break;>		ca ea3:>			mprrotf("rd");>			break;>		ncfauli:>			mprrotf("te");>			break;>	}>}


/* Displn roteesu asdslsars and c exs.�Theavalusspaa ed is aa um dstoR�de roteesu c exs.�es. */dslsar(n)R�rotsn;R�{R�	mprrotf("$%u.",n 100);		
wholodolsars,�.h>	aatwo4n%s100);				
two%digrtt�c exs�.h>}


Set ith prrveleesslow lines. */detprrv(d,v)R�char�.s;R�rots*v;R�{R�	dtysc. r(d);>	if�(dercmp(d,"tage") == 0)�.v= TWIT;>	if�(dercmp(d,"d/*grac ") == 0)�.v= DISGRACE;>	if�(dercmp(d,"nrrmal") == 0)�.v= NORMAL;>	if�(dercmp(d,"prrvel") == 0)�.v= PRIVEL;>	if�(dercmp(d,"thera") == 0)�.v= EXTRA;>	if�(dercmp(d,"dysop") == 0)�.v= SYSOP;>}


/* Dispith curr ex prrveleesslow lines. */getprrv(n)R�rotsn;R�{R�	dagech4n) {R�		ca eaTWIT:>			mprrotf("Tage");>			break;>		ca eaDISGRACE:>			mprrotf("D/*grac ");>			break;>		ca eaNORMAL:>			mprrotf("Nrrmal");>			break;>		ca eaPRIVEL:>			mprrotf("Prrvel");>			break;>		ca eaEXTRA:>			mprrotf("Ehera");>			break;>		ca eaSYSOP:>			mprrotf("Sysop");>			break;>		ncfauli:>			mprrotf("BADaPRIV =%d",n);>			break;>	}>}


/* Disptrme ashh:mm,�frompith absoluteayroutes-v>
e-yrdnrte.�.h>R�y>_trmeeesslow lines. */aatwo4n 60);R�	ycenrt (':');R�	aatwo4n%s60);>}


/* Displanumb r astwo%digrtt,sage w#eadrog zeros aaanecc a auy.�.h>R�aatwo4nsslow lines. */if�(nlus10) ycenrt ('0');R�	mprrotf("%u",n);>}


/* Dispith trme.�Theavalusspaa ed is hh:mm su mm:st,sro ege er*/hours *s60 *syroutes su mroutes *s60 +secends.�es. */cy>_trmeeesslow lines. */aatwo4n 60);R�	lcenrt (':');R�	aatwo4n%s60);>}


/* Displanumb r astwo%digrtt,sage w#eadrog zeros aaanecc a auy.�.h>R�caatwo4nsslow lines. */if�(nlus10) lcenrt ('0');R�	cprrotf("%u",n);>}

Same asy>_trme,�ex
eptityith scg filo.�.h>R�ly>_trmeeesslow lines. */laatwo4n 60);R�	lprrotf(":");>	laatwo4n%s60);>}


/* Displanumb r astwo%digrtt,sage w#eadrog zeros aaanecc a auy.�.h>R�laatwo4nsslow lines. */if�(nlus10) lprrotf("0");R�	lprrotf("%u",n);>}
